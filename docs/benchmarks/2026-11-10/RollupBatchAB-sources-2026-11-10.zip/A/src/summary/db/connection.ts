// 통계 SQLite 연결의 설정·마이그레이션·트랜잭션·수명을 관리한다.
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { DatabaseSync, type StatementSync } from 'node:sqlite';
import { migrateSchema } from './migrations';
import { calendarPeriod } from './timezone';
import { UsageRollupStore } from './rollups';
import { modelOrderKey, modelRelease } from '../models/modelOrder';
import type { StageProfiler, StorageStage } from '../profiling';

export type SqliteSessionOptions = string | { databasePath: string; cacheKiB?: number };

/** 공유 SQLite 연결·고정 쿼리 캐시·트랜잭션과 유지보수를 관리한다. */
export class SqliteSession {
  readonly connection: DatabaseSync;
  readonly rollups: UsageRollupStore;
  private closed = false;
  private lastOptimizedAt: number | undefined;
  // Cache only fixed statements, so its size is independent of files, sessions and user queries.
  private readonly statements = new Map<string, StatementSync>();

  constructor(options: SqliteSessionOptions) {
    const path = typeof options === 'string' ? options : options.databasePath;
    const cacheKiB = typeof options === 'string' ? 4096 : options.cacheKiB ?? 4096;
    if (!Number.isSafeInteger(cacheKiB) || cacheKiB < 256 || cacheKiB > 65536) {
      throw new RangeError('Database cache must be between 256 and 65536 KiB');
    }
    if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
    this.connection = new DatabaseSync(path);
    try {
      this.connection.exec(`PRAGMA busy_timeout = 5000;
        PRAGMA foreign_keys = ON;
        PRAGMA journal_mode = WAL;
        PRAGMA temp_store = FILE;
        PRAGMA cache_size = -${cacheKiB};
        PRAGMA temp.cache_size = -${cacheKiB};
        PRAGMA mmap_size = 0;`);
      migrateSchema(this.connection, action => this.transaction(action));
      this.optimizeConnection(true);
      this.connection.function('agent_tracker_period', { deterministic: true }, (timestamp, timezone, unit) => {
        if (timestamp === null) return null;
        return calendarPeriod(Number(timestamp), String(timezone), unit === 'month' ? 'month' : 'day');
      });
      this.rollups = new UsageRollupStore(this);
      this.connection.function('agent_tracker_model_release', { deterministic: true }, model => modelRelease(String(model ?? '')));
      this.connection.function('agent_tracker_model_key', { deterministic: true }, model => modelOrderKey(String(model ?? '')));
    } catch (error) {
      this.connection.close();
      throw error;
    }
  }

  statement(sql: string): StatementSync {
    let statement = this.statements.get(sql);
    if (!statement) {
      statement = this.connection.prepare(sql);
      this.statements.set(sql, statement);
    }
    return statement;
  }

  /**
   * 책임: 동기 DB 변경을 하나의 원자적 쓰기로 묶는다.
   * 알고리즘: BEGIN IMMEDIATE로 쓰기 잠금을 확보한 뒤 콜백 성공 시 COMMIT하고 오류 시 ROLLBACK 후 같은 오류를 전달한다.
   */
  transaction<T>(action: () => T, profile?: StageProfiler<StorageStage>): T {
    const execute = (stage: 'begin' | 'commit' | 'rollback', sql: string): void => {
      if (profile) profile.measure(stage, () => this.connection.exec(sql));
      else this.connection.exec(sql);
    };
    execute('begin', 'BEGIN IMMEDIATE');
    try {
      const result = action();
      execute('commit', 'COMMIT');
      return result;
    } catch (error) {
      execute('rollback', 'ROLLBACK');
      throw error;
    }
  }

  /**
   * 책임: 조회 계획용 통계를 과도한 유지보수 비용 없이 갱신한다.
   * 알고리즘: 첫 스캔 완료 후와 이후 하루 간격으로 main.optimize를 시도하고 성공한 시각만 기록하며 유지보수 실패는 전파하지 않는다.
   */
  optimize(): void {
    const now = Date.now();
    if (this.lastOptimizedAt !== undefined && now - this.lastOptimizedAt < 86_400_000) return;
    if (this.optimizeConnection()) this.lastOptimizedAt = now;
  }

  close(): void {
    if (!this.closed) {
      this.optimizeConnection();
      this.statements.clear();
      this.connection.close();
      this.closed = true;
    }
  }

  private optimizeConnection(onOpen = false): boolean {
    try {
      // Limit maintenance to persistent tables.
      this.connection.exec(onOpen ? 'PRAGMA main.optimize=0x10002;' : 'PRAGMA main.optimize;');
      return true;
    } catch {
      // Statistics are optional; a competing writer must not fail a scan or cleanup.
      return false;
    }
  }
}
