// 통계 DB의 테이블·인덱스·버전과 기존 스키마 변환 SQL을 정의한다.
import { SCHEMA_ROLLUP_SQL } from './rollup-state';

export { SCHEMA_ROLLUP_SQL } from './rollup-state';
export const SCHEMA_VERSION = 18;

/**
 * 책임: 파일 이동 판정에 필요한 플랫폼별 identity 인덱스를 구성한다.
 * 알고리즘: device·inode를 이동 판정에 쓰지 않는 Windows는 인덱스를 제거하고 다른 운영체제에서는 제공자·device·inode 인덱스를 생성한다.
 */
export function manifestIdentityIndexSql(platform: NodeJS.Platform): string {
  return platform === 'win32' ? 'DROP INDEX IF EXISTS idx_manifest_identity;'
    : 'CREATE INDEX IF NOT EXISTS idx_manifest_identity ON manifest(provider, dev, inode);';
}

export const SCHEMA_CAPABILITY_SQL = `
CREATE TABLE IF NOT EXISTS turn_capability_usage (
  turn_id INTEGER NOT NULL REFERENCES turn_summary(id) ON DELETE CASCADE,
  category TEXT NOT NULL CHECK(category IN ('skill','subagent','plugin','model')),
  name TEXT NOT NULL,
  usage_count INTEGER NOT NULL CHECK(usage_count > 0),
  PRIMARY KEY(turn_id, category, name)
) WITHOUT ROWID;
`;

export const SCHEMA_MODEL_SQL = `
CREATE TABLE IF NOT EXISTS turn_model_usage (
  turn_id INTEGER NOT NULL REFERENCES turn_summary(id) ON DELETE CASCADE,
  model TEXT NOT NULL,
  input_tokens INTEGER NOT NULL CHECK(input_tokens >= 0),
  output_tokens INTEGER NOT NULL CHECK(output_tokens >= 0),
  cache_write_input_tokens INTEGER CHECK(cache_write_input_tokens >= 0),
  cache_read_input_tokens INTEGER CHECK(cache_read_input_tokens >= 0),
  estimated_cost_usd REAL CHECK(estimated_cost_usd >= 0),
  pricing_version TEXT NOT NULL,
  PRIMARY KEY(turn_id, model)
) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS session_billing (
  provider TEXT NOT NULL,
  session_id TEXT NOT NULL,
  billing_mode TEXT NOT NULL CHECK(billing_mode IN ('subscription','api','unknown')),
  PRIMARY KEY(provider,session_id),
  FOREIGN KEY(provider,session_id) REFERENCES sessions(provider,session_id) ON DELETE CASCADE
) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS turn_costs (
  turn_id INTEGER PRIMARY KEY REFERENCES turn_summary(id) ON DELETE CASCADE,
  billing_mode TEXT NOT NULL CHECK(billing_mode IN ('subscription','api','unknown')),
  cost_usd REAL CHECK(cost_usd >= 0),
  unknown_costs INTEGER NOT NULL CHECK(unknown_costs >= 0),
  pricing_version TEXT NOT NULL
);
`;

const NAMES_SQL = `
CREATE TABLE IF NOT EXISTS projects (
  project_key TEXT PRIMARY KEY,
  project_name TEXT NOT NULL
) WITHOUT ROWID;
CREATE TABLE IF NOT EXISTS sessions (
  provider TEXT NOT NULL CHECK(provider IN ('claude', 'codex')),
  session_id TEXT NOT NULL,
  session_name TEXT,
  PRIMARY KEY(provider, session_id)
) WITHOUT ROWID;
`;

const TURN_SUMMARY_SQL = `
CREATE TABLE IF NOT EXISTS turn_summary (
  id INTEGER PRIMARY KEY,
  provider TEXT NOT NULL CHECK(provider IN ('claude', 'codex')),
  project_key TEXT NOT NULL REFERENCES projects(project_key),
  session_id TEXT NOT NULL,
  root_turn_id TEXT NOT NULL,
  request_title TEXT,
  started_at_ms INTEGER,
  completed_at_ms INTEGER,
  duration_ms INTEGER CHECK(duration_ms >= 0),
  duration_quality TEXT NOT NULL CHECK(duration_quality IN ('exact','derived','approximate','missing')),
  input_tokens INTEGER NOT NULL CHECK(input_tokens >= 0),
  output_tokens INTEGER NOT NULL CHECK(output_tokens >= 0),
  cache_write_input_tokens INTEGER CHECK(cache_write_input_tokens >= 0),
  cache_read_input_tokens INTEGER CHECK(cache_read_input_tokens >= 0),
  total_tokens INTEGER NOT NULL CHECK(total_tokens = input_tokens + output_tokens),
  status TEXT NOT NULL CHECK(status IN ('completed','in_progress','failed')),
  quality_flags TEXT,
  diagnostic_file_id INTEGER REFERENCES manifest(id) ON DELETE SET NULL,
  diagnostic_offset INTEGER,
  last_error TEXT,
  updated_at TEXT NOT NULL,
  UNIQUE(provider, session_id, root_turn_id),
  FOREIGN KEY(provider, session_id) REFERENCES sessions(provider, session_id)
);
`;

const TURN_SUMMARY_INDEX_SQL = `
CREATE INDEX IF NOT EXISTS idx_summary_period ON turn_summary(started_at_ms, provider);
CREATE INDEX IF NOT EXISTS idx_summary_project_period ON turn_summary(provider, project_key, started_at_ms);
`;

export const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS manifest (
  id INTEGER PRIMARY KEY,
  provider TEXT NOT NULL CHECK(provider IN ('claude', 'codex')),
  source_root TEXT NOT NULL,
  path TEXT NOT NULL,
  session_id TEXT,
  size_bytes INTEGER NOT NULL DEFAULT 0 CHECK(size_bytes >= 0),
  mtime_ms REAL NOT NULL DEFAULT 0,
  dev TEXT,
  inode TEXT,
  parser_version INTEGER NOT NULL DEFAULT 0,
  source_identity TEXT,
  content_hash TEXT,
  capabilities_collected INTEGER NOT NULL DEFAULT 0 CHECK(capabilities_collected IN (0,1)),
  source_missing INTEGER NOT NULL DEFAULT 0 CHECK(source_missing IN (0,1)),
  last_seen_scan_id TEXT,
  processing_status TEXT NOT NULL DEFAULT 'processing'
    CHECK(processing_status IN ('processing','done','error','interrupted')),
  processing_position TEXT,
  recorded_at TEXT NOT NULL,
  last_error TEXT,
  UNIQUE(provider, path)
);
${manifestIdentityIndexSql(process.platform)}
CREATE INDEX IF NOT EXISTS idx_manifest_root_id ON manifest(provider, source_root, id);
CREATE INDEX IF NOT EXISTS idx_manifest_session ON manifest(provider, session_id, id);
CREATE INDEX IF NOT EXISTS idx_manifest_source ON manifest(provider, source_identity, id);
${NAMES_SQL}
${TURN_SUMMARY_SQL}
${TURN_SUMMARY_INDEX_SQL}
${SCHEMA_MODEL_SQL}
${SCHEMA_CAPABILITY_SQL}
${SCHEMA_ROLLUP_SQL}
`;

/** Both v1 and v2 stored project names on every turn. Preserve ids, statistics and diagnostics. */
export const SCHEMA_LEGACY_MIGRATION_SQL = `
${NAMES_SQL}
INSERT INTO projects SELECT project_key, MIN(project_name) FROM turn_summary GROUP BY project_key;
INSERT INTO sessions SELECT DISTINCT provider, session_id, NULL FROM turn_summary;
ALTER TABLE turn_summary RENAME TO turn_summary_legacy;
${TURN_SUMMARY_SQL}
INSERT INTO turn_summary (id, provider, project_key, session_id, root_turn_id,
  started_at_ms, completed_at_ms, duration_ms, duration_quality,
  input_tokens, output_tokens, total_tokens, status, quality_flags,
  diagnostic_file_id, diagnostic_offset, last_error, updated_at)
SELECT id, provider, project_key, session_id, root_turn_id,
  started_at_ms, completed_at_ms, duration_ms, duration_quality,
  input_tokens, output_tokens, total_tokens, status, quality_flags,
  diagnostic_file_id, diagnostic_offset, last_error, updated_at FROM turn_summary_legacy;
DROP TABLE turn_summary_legacy;
${TURN_SUMMARY_INDEX_SQL}
`;

/** Keep totals available until the next scan reconstructs previously discarded cache components. */
export const SCHEMA_CACHE_MIGRATION_SQL = `
ALTER TABLE turn_summary ADD COLUMN cache_write_input_tokens INTEGER CHECK(cache_write_input_tokens >= 0);
ALTER TABLE turn_summary ADD COLUMN cache_read_input_tokens INTEGER CHECK(cache_read_input_tokens >= 0);
`;

/** Drop only the unused ordinal; keep request ids and all referencing rows intact. */
export const SCHEMA_TURN_INDEX_MIGRATION_SQL = `
DROP INDEX IF EXISTS idx_summary_session;
ALTER TABLE turn_summary DROP COLUMN turn_index;
`;
