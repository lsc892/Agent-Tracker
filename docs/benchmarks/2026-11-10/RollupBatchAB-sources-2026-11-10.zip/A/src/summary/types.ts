// 통계 API의 설정·조회 결과와 제공자 공통 파싱 이벤트 타입을 정의한다.
export type Provider = 'claude' | 'codex';
export interface SourceRoot { provider: Provider; path: string; dataHome?: string }
export interface SummaryOptions {
  collectCapabilities?: boolean;
  retainDeletedSourceUsage?: boolean;
  dbPath: string;
  roots: SourceRoot[];
  timezone?: string;
  workerPath?: string;
  maxLineBytes?: number;
  /** 파일 준비 Worker 수. 1은 순차 처리이며 기본은 사용 가능한 CPU에 맞춰 최대 4개다. */
  sourceWorkers?: number;
  cancellation?: SharedArrayBuffer;
}
export interface UsageQuery {
  section?: 'tokens' | 'skills';
  capabilityOffsets?: Partial<Record<import('./db/types').CapabilityCategory, number>>;
  capabilityLimits?: Partial<Record<import('./db/types').CapabilityCategory, number>>;
  includeCosts?: boolean;
  excludeEmptyUsage?: boolean;
  groupBy?: 'day' | 'month' | 'project' | 'session' | 'all' | 'turn';
  timezone?: string;
  fromMs?: number;
  toMs?: number;
  provider?: Provider;
  providers?: Provider[];
  projectKey?: string;
  sessionId?: string;
  projectName?: string;
  sessionName?: string;
  limit?: number;
  offset?: number;
  tableSort?: import('./db/types').UsageSort;
  afterId?: number;
  chartMetric?: import('./db/types').ChartMetric;
  chartBy?: 'provider' | 'model';
}
export interface NameQuery {
  kind: 'project' | 'session';
  provider?: Provider;
  providers?: Provider[];
  projectKey?: string;
  limit?: number;
  offset?: number;
}
export interface NameOption {
  project_key: string;
  project_name: string;
  provider: Provider | null;
  session_id: string | null;
  session_name: string | null;
  session_started_at_ms: number | null;
}
export interface NameResult { rows: NameOption[]; total: number }
export interface RefreshResult {
  scanId: string;
  discovered: number;
  parsed: number;
  reused: number;
  failed: number;
  bodyBytes: number;
  interrupted: boolean;
  completedAt: string;
  error?: string;
  timings?: import('./profiling').RefreshTimings;
}
export interface SummaryProgress {
  phase: 'scanning' | 'parsing' | 'committing' | 'complete';
  discovered: number;
  parsed: number;
  failed: number;
  bodyBytes: number;
}
export interface UsageResult {
  by?: 'provider' | 'model';
  capabilitiesEnabled?: boolean;
  capabilities?: Record<import('./db/types').CapabilityCategory, import('./db/types').CapabilityPage>;
  billing?: import('./db/types').BillingMode;
  rows: import('./db/types').UsageRow[] | import('./db/types').TurnSummaryRow[];
  total: number;
  coverage: import('./db/types').DiagnosticsPage['counts'];
  chart?: import('./db/types').UsageChart;
}
export type DiagnosticsResult = import('./db/types').DiagnosticsPage & { lastRefresh?: RefreshResult };
export interface TokenVector {
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
  reasoning: number;
}
export interface FileContext {
  collectCapabilities?: boolean;
  provider: Provider;
  path: string;
  sourceRoot: string;
  fileId: number;
}
export interface ParsedIdentity {
  sessionId: string;
  threadId: string;
  parentThreadId: string | null;
  projectKey: string;
  projectName: string;
  sessionName?: string;
  isMain: boolean;
  forkedFromId?: string | null;
  agentPath?: string;
  rootlessSubagent?: boolean;
  parentRootId?: string;
  standaloneSubagent?: boolean;
}
export interface TurnEvent {
  kind: 'turn';
  rootId: string;
  isMain: boolean;
  title?: string;
  startedAt?: number | null;
  completedAt?: number | null;
  lastAssistantAt?: number | null;
  duration?: number | null;
  durationQuality?: 'exact' | 'derived' | 'approximate' | 'missing';
  completed?: boolean;
  /** Aborted outcomes remain transient and never become persisted request summaries. */
  status?: 'completed' | 'in_progress' | 'failed' | 'aborted';
  statusAt?: number | null;
  flags?: string[];
  offset: number;
}
export interface UsageEvent {
  kind: 'usage';
  rootId: string;
  responseId: string;
  requestId: string | null;
  threadId: string;
  turnId: string;
  tokens: TokenVector;
  model?: string;
  billingMode?: import('./db/types').BillingMode;
  schema?: 'current' | 'legacy';
  flags?: string[];
  offset: number;
}
export interface CheckEvent {
  kind: 'check'; rootId: string; threadId: string; turnId: string;
  tokens: TokenVector; offset: number;
}
export interface CapabilityEvent {
  kind: 'capability'; rootId: string; threadId: string; eventId: string;
  category: Exclude<import('./db/types').CapabilityCategory, 'model'>;
  name: string; offset: number;
}
export type ParseEvent = TurnEvent | UsageEvent | CheckEvent | CapabilityEvent;
export interface ParseSink {
  identity(identity: ParsedIdentity): void;
  event(event: ParseEvent): void;
  child?(reference: string, rootId: string): void;
}
