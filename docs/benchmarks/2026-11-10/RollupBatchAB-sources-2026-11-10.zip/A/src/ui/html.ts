// 통계·진단·색상 설정 Webview의 초기 HTML과 실행 자원 경계를 구성한다.
import { getLocale, localizationScripts, t } from '../localization';
import { escapeHtml } from './presentation';
import { settingDefinitions } from '../configuration/schema';

function pageSizeInput(id: string): string {
  return `<label class="page-size"><span data-i18n="dashboard.rowsPerPage">${escapeHtml(t('dashboard.rowsPerPage'))}</span><input id="${id}" type="number" min="1" max="1000" step="1" value="100" required inputmode="numeric" data-i18n-title="dashboard.pageSizeHelp" title="${escapeHtml(t('dashboard.pageSizeHelp'))}"></label>`;
}

/**
 * 책임: 색상 설정 입력과 미리 보기에 필요한 초기 화면을 만든다.
 * 알고리즘: 공통 기본 색상·번역 문구를 escape해 폼에 넣고 CSP와 nonce로 연결된 로컬 스크립트만 실행하게 한다.
 */
export function colorSettingsHtml(scriptUri:string,styleUri:string,cspSource:string,nonce:string):string {
  return `<!DOCTYPE html><html lang="${escapeHtml(getLocale())}"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${escapeHtml(cspSource)}; script-src 'nonce-${escapeHtml(nonce)}';">
<title data-i18n="color.title">${escapeHtml(t('color.title'))}</title><link rel="stylesheet" href="${escapeHtml(styleUri)}"></head>
<body><header><div><p class="eyebrow">AGENT TRACKER</p><h1><span data-i18n="color.heading">${escapeHtml(t('color.heading'))}</span></h1><p class="muted"><span data-i18n="color.description">${escapeHtml(t('color.description'))}</span></p></div></header>
<main><form id="color-settings" class="color-settings">
<label><span data-i18n="color.mode">${escapeHtml(t('color.mode'))}</span><select id="color-mode"><option value="automatic" data-i18n="common.automatic">${escapeHtml(t('common.automatic'))}</option><option value="white" data-i18n="color.white">${escapeHtml(t('color.white'))}</option><option value="black" data-i18n="color.black">${escapeHtml(t('color.black'))}</option><option value="custom" data-i18n="color.custom">${escapeHtml(t('color.custom'))}</option></select></label>
<p class="muted note"><span data-i18n="color.automaticHelp">${escapeHtml(t('color.automaticHelp'))}</span></p>
<div class="color-inputs"><label><span data-i18n="color.picker">${escapeHtml(t('color.picker'))}</span><input id="color-picker" type="color" value="${settingDefinitions.display.customColor.default}" data-i18n-aria-label="color.pickerAccessible" aria-label="${escapeHtml(t('color.pickerAccessible'))}"></label><label><span data-i18n="color.hex">${escapeHtml(t('color.hex'))}</span><input id="color-hex" type="text" value="${settingDefinitions.display.customColor.default}" data-i18n-placeholder="color.hexPlaceholder" placeholder="${escapeHtml(t('color.hexPlaceholder'))}" maxlength="9" spellcheck="false" autocomplete="off"></label></div>
<label><span data-i18n="color.opacity">${escapeHtml(t('color.opacity'))}</span> <output id="color-opacity-value">100%</output><input id="color-opacity" type="range" min="0" max="255" value="255" step="1"></label>
<p class="muted note"><span data-i18n="color.inputHelp">${escapeHtml(t('color.inputHelp'))}</span></p>
<p class="muted"><span data-i18n="color.preview">${escapeHtml(t('color.preview'))}</span></p><div id="color-preview" class="color-preview"><span data-i18n="color.previewText">${escapeHtml(t('color.previewText'))}</span></div>
<label><span data-i18n="color.target">${escapeHtml(t('color.target'))}</span><select id="color-target"><option value="user" data-i18n="color.userTarget">${escapeHtml(t('color.userTarget'))}</option><option value="workspace" data-i18n="color.workspaceTarget">${escapeHtml(t('color.workspaceTarget'))}</option></select></label><p class="muted note"><span data-i18n="color.targetHelp">${escapeHtml(t('color.targetHelp'))}</span></p>
<p id="color-status" role="status" aria-live="polite"></p><button id="color-apply" type="submit"><span data-i18n="common.apply">${escapeHtml(t('common.apply'))}</span></button>
</form></main>${localizationScripts(scriptUri, nonce)}<script nonce="${escapeHtml(nonce)}" src="${escapeHtml(scriptUri)}"></script></body></html>`;
}

/**
 * 책임: 통계 화면의 초기 HTML과 실행 자원 경계를 구성한다.
 * 알고리즘: 번역·외부 속성 값을 HTML escape하고 CSP로 자원을 차단한 뒤 nonce를 가진 로컬 스크립트와 스타일만 연결한다.
 */
export function dashboardHtml(scriptUri: string, styleUri: string, cspSource: string, nonce: string): string {
  return `<!DOCTYPE html>
<html lang="${escapeHtml(getLocale())}"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${escapeHtml(cspSource)}; script-src 'nonce-${escapeHtml(nonce)}';">
<title>Agent Tracker</title><link rel="stylesheet" href="${escapeHtml(styleUri)}"></head>
<body><header><div><p class="eyebrow">AGENT TRACKER</p><h1><span data-i18n="dashboard.heading">${escapeHtml(t('dashboard.heading'))}</span></h1><p class="muted"><span data-i18n="dashboard.description">${escapeHtml(t('dashboard.description'))}</span></p></div><button id="settings"><span data-i18n="common.settings">${escapeHtml(t('common.settings'))}</span></button></header>
<main><p id="configuration-warning" class="stale" role="status" hidden></p><p id="error" class="error" role="alert" hidden></p>
<section id="usage" data-i18n-aria-label="dashboard.usageStatistics" aria-label="${escapeHtml(t('dashboard.usageStatistics'))}"><div class="section-title"><div><h2><span data-i18n="dashboard.usageStatistics">${escapeHtml(t('dashboard.usageStatistics'))}</span></h2></div><div class="actions"><button id="cancel-usage" hidden><span data-i18n="common.cancel">${escapeHtml(t('common.cancel'))}</span></button></div></div>
<p id="usage-progress" role="status" aria-live="polite"></p>
<div class="segmented statistics-sections" role="group" data-i18n-aria-label="dashboard.statisticsSections" aria-label="${escapeHtml(t('dashboard.statisticsSections'))}"><button id="section-tokens" type="button" aria-pressed="true" aria-controls="token-section"><span data-i18n="common.tokens">${escapeHtml(t('common.tokens'))}</span></button><button id="section-skills" type="button" aria-pressed="false" aria-controls="skill-section"><span data-i18n="common.skillSection">${escapeHtml(t('common.skillSection'))}</span></button></div>
<form id="usage-filters" class="filters">
<label id="group-control"><span data-i18n="dashboard.queryUnit">${escapeHtml(t('dashboard.queryUnit'))}</span><select id="group"><option value="day" data-i18n="dashboard.daily">${escapeHtml(t('dashboard.daily'))}</option><option value="month" data-i18n="dashboard.monthly">${escapeHtml(t('dashboard.monthly'))}</option><option value="project" data-i18n="dashboard.byProject">${escapeHtml(t('dashboard.byProject'))}</option><option value="session" data-i18n="dashboard.bySession">${escapeHtml(t('dashboard.bySession'))}</option><option value="turn" data-i18n="dashboard.byRequest">${escapeHtml(t('dashboard.byRequest'))}</option><option value="all" data-i18n="common.all">${escapeHtml(t('common.all'))}</option></select></label>
<label><span data-i18n="common.provider">${escapeHtml(t('common.provider'))}</span><select id="provider"><option value="" data-i18n="common.all">${escapeHtml(t('common.all'))}</option><option value="claude">Claude</option><option value="codex">Codex</option></select></label>
<div id="chart-by-control" class="filter-toggle"><span><span data-i18n="dashboard.grouping">${escapeHtml(t('dashboard.grouping'))}</span></span><div class="segmented" role="group" data-i18n-aria-label="dashboard.grouping" aria-label="${escapeHtml(t('dashboard.grouping'))}"><button id="chart-provider" type="button" aria-pressed="true"><span data-i18n="dashboard.byProvider">${escapeHtml(t('dashboard.byProvider'))}</span></button><button id="chart-model" type="button" aria-pressed="false"><span data-i18n="dashboard.byModel">${escapeHtml(t('dashboard.byModel'))}</span></button></div></div>
${(['from', 'to'] as const).map(bound => {
    const caption = bound === 'from' ? 'dashboard.fromDate' : 'dashboard.toDate';
    return `<div class="date-filter"><label for="${bound}-day" data-i18n="${caption}">${escapeHtml(t(caption))}</label><div class="date-input"><input id="${bound}-day" type="text" placeholder="year-month-day" inputmode="numeric" pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" maxlength="10" autocomplete="off" spellcheck="false"><input id="${bound}-day-picker" type="date" data-i18n-aria-label="${caption}" aria-label="${escapeHtml(t(caption))}"></div></div>`;
  }).join('')}
<div class="name-picker" id="project-picker"><span id="project-caption"><span data-i18n="dashboard.projectName">${escapeHtml(t('dashboard.projectName'))}</span></span><button id="project-name" type="button" aria-labelledby="project-caption project-name" aria-expanded="false" aria-controls="project-options"><span data-i18n="dashboard.allProjects">${escapeHtml(t('dashboard.allProjects'))}</span></button><div id="project-options" class="name-options" role="group" data-i18n-aria-label="dashboard.projectList" aria-label="${escapeHtml(t('dashboard.projectList'))}" hidden><div id="project-list"></div><p id="project-list-status" class="muted" role="status"></p></div></div>
<div class="name-picker" id="session-picker"><span id="session-caption"><span data-i18n="dashboard.sessionName">${escapeHtml(t('dashboard.sessionName'))}</span></span><button id="session-name" type="button" aria-labelledby="session-caption session-name" aria-expanded="false" aria-controls="session-options"><span data-i18n="dashboard.allSessions">${escapeHtml(t('dashboard.allSessions'))}</span></button><div id="session-options" class="name-options" role="group" data-i18n-aria-label="dashboard.sessionList" aria-label="${escapeHtml(t('dashboard.sessionList'))}" hidden><div id="session-list"></div><p id="session-list-status" class="muted" role="status"></p></div></div><button type="submit"><span data-i18n="common.query">${escapeHtml(t('common.query'))}</span></button><button id="reset-filters" type="button"><span data-i18n="common.reset">${escapeHtml(t('common.reset'))}</span></button></form>
<p id="timezone" class="muted"></p>
<div id="token-section">
<div class="cost-controls"><label id="billing-control" hidden><span data-i18n="dashboard.billingMode">${escapeHtml(t('dashboard.billingMode'))}</span> <select id="billing-mode"><option value="unknown" data-i18n="common.unconfirmed">${escapeHtml(t('common.unconfirmed'))}</option><option value="subscription" data-i18n="dashboard.subscription">${escapeHtml(t('dashboard.subscription'))}</option><option value="api" data-i18n="dashboard.prepaidApi">${escapeHtml(t('dashboard.prepaidApi'))}</option></select></label></div>
<p id="cost-note" class="muted note" hidden><span data-i18n="dashboard.costNote">${escapeHtml(t('dashboard.costNote'))}</span></p>
<section class="usage-chart" data-i18n-aria-label="dashboard.usageChart" aria-label="${escapeHtml(t('dashboard.usageChart'))}"><div class="chart-heading"><h3 id="chart-title"><span data-i18n="dashboard.totalTokens">${escapeHtml(t('dashboard.totalTokens'))}</span></h3><label><span data-i18n="dashboard.chartMetric">${escapeHtml(t('dashboard.chartMetric'))}</span> <select id="chart-metric"><option value="tokens" data-i18n="dashboard.totalTokens">${escapeHtml(t('dashboard.totalTokens'))}</option><option value="averageTokens" data-i18n="dashboard.averageTokens">${escapeHtml(t('dashboard.averageTokens'))}</option><option value="averageDuration" data-i18n="dashboard.averageTime">${escapeHtml(t('dashboard.averageTime'))}</option><option value="requests" data-i18n="dashboard.requests">${escapeHtml(t('dashboard.requests'))}</option></select></label></div><p id="chart-scope" class="muted"></p><ul id="chart-legend" class="chart-legend" data-i18n-aria-label="dashboard.tokenLegend" aria-label="${escapeHtml(t('dashboard.tokenLegend'))}" hidden></ul><div id="usage-chart" class="chart-plot"></div><p id="chart-detail" class="chart-detail muted" aria-live="polite"></p></section>
<div class="pagination" data-i18n-aria-label="dashboard.chartPages" aria-label="${escapeHtml(t('dashboard.chartPages'))}">${pageSizeInput('chart-page-size')}<button id="chart-previous" type="button" disabled><span data-i18n="common.previous">${escapeHtml(t('common.previous'))}</span></button><span id="chart-page-label"></span><button id="chart-next" type="button" disabled><span data-i18n="common.next">${escapeHtml(t('common.next'))}</span></button></div>
<div id="usage-table" class="table-wrap"></div><div class="pagination" data-i18n-aria-label="dashboard.tablePages" aria-label="${escapeHtml(t('dashboard.tablePages'))}">${pageSizeInput('page-size')}<button id="previous"><span data-i18n="common.previous">${escapeHtml(t('common.previous'))}</span></button><span id="page-label"></span><button id="next"><span data-i18n="common.next">${escapeHtml(t('common.next'))}</span></button></div><p id="coverage" class="muted"></p>
<p id="model-note" class="muted note" hidden><span data-i18n="dashboard.modelNote">${escapeHtml(t('dashboard.modelNote'))}</span></p>
<p class="muted note"><span data-i18n="dashboard.tokenNote">${escapeHtml(t('dashboard.tokenNote'))}</span></p>
<p class="muted note"><span data-i18n="dashboard.averageNote">${escapeHtml(t('dashboard.averageNote'))}</span></p></div>
<div id="skill-section" hidden><h3><span data-i18n="dashboard.skillHeading">${escapeHtml(t('dashboard.skillHeading'))}</span></h3>
<div id="skill-disabled" hidden><p class="muted"><span data-i18n="dashboard.skillsDisabled">${escapeHtml(t('dashboard.skillsDisabled'))}</span></p><button id="skill-settings" type="button"><span data-i18n="common.openSettings">${escapeHtml(t('common.openSettings'))}</span></button></div>
<div id="skill-content">
${(['skill','subagent','plugin','model'] as const).map(category=>`<section class="capability-statistics" data-i18n-category="${category}" aria-label="${escapeHtml(t('dashboard.categoryStatistics', {value0:t(`common.${category}`)}))}"><div class="chart-heading"><h3><span data-i18n="common.${category}">${escapeHtml(t(`common.${category}`))}</span></h3><span id="${category}-total" class="muted"></span></div><div id="${category}-table" class="table-wrap"></div><div class="pagination">${pageSizeInput(`${category}-page-size`)}<button id="${category}-previous" type="button"><span data-i18n="common.previous">${escapeHtml(t('common.previous'))}</span></button><span id="${category}-page"></span><button id="${category}-next" type="button"><span data-i18n="common.next">${escapeHtml(t('common.next'))}</span></button></div></section>`).join('')}
<p class="muted note"><span data-i18n="dashboard.aiCallsNote">${escapeHtml(t('dashboard.aiCallsNote'))}</span></p>
<p class="muted note"><span data-i18n="dashboard.capabilityRatioNote">${escapeHtml(t('dashboard.capabilityRatioNote'))}</span></p>
<p class="muted note"><span data-i18n="dashboard.capabilityNote">${escapeHtml(t('dashboard.capabilityNote'))}</span></p>
</div></div></section>
<footer class="dashboard-footer"><a id="open-diagnostics" href="#"><span data-i18n="diagnostics.heading">${escapeHtml(t('diagnostics.heading'))}</span></a></footer>
</main>${localizationScripts(scriptUri, nonce)}<script nonce="${escapeHtml(nonce)}" src="${escapeHtml(scriptUri)}"></script></body></html>`;
}

/**
 * 책임: 저장된 파일·요청 진단을 보여 줄 초기 화면을 구성한다.
 * 알고리즘: 진단 표·페이지 조작 영역과 번역을 조립하고 속성 escape·CSP·nonce를 적용해 로컬 자원만 연결한다.
 */
export function diagnosticsHtml(scriptUri: string, styleUri: string, cspSource: string, nonce: string): string {
  return `<!DOCTYPE html>
<html lang="${escapeHtml(getLocale())}"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${escapeHtml(cspSource)}; script-src 'nonce-${escapeHtml(nonce)}';">
<title data-i18n="diagnostics.title">${escapeHtml(t('diagnostics.title'))}</title><link rel="stylesheet" href="${escapeHtml(styleUri)}"></head>
<body><header><div><p class="eyebrow">AGENT TRACKER</p><h1><span data-i18n="diagnostics.heading">${escapeHtml(t('diagnostics.heading'))}</span></h1><p class="muted"><span data-i18n="diagnostics.description">${escapeHtml(t('diagnostics.description'))}</span></p></div><button id="settings"><span data-i18n="common.settings">${escapeHtml(t('common.settings'))}</span></button></header>
<main><p id="configuration-warning" class="stale" role="status" hidden></p><p id="error" class="error" role="alert" hidden></p>
<section id="diagnostics" data-i18n-aria-label="diagnostics.heading" aria-label="${escapeHtml(t('diagnostics.heading'))}"><div class="section-title"><h2><span data-i18n="diagnostics.fileStatus">${escapeHtml(t('diagnostics.fileStatus'))}</span></h2><button id="refresh-diagnostics" data-i18n-title="diagnostics.reloadHelp" title="${escapeHtml(t('diagnostics.reloadHelp'))}"><span data-i18n="diagnostics.reload">${escapeHtml(t('diagnostics.reload'))}</span></button></div><p id="diagnostic-counts"></p><div id="diagnostic-files" class="table-wrap"></div><div class="pagination"><button id="diagnostic-previous"><span data-i18n="common.previous">${escapeHtml(t('common.previous'))}</span></button><span id="diagnostic-page"></span><button id="diagnostic-next"><span data-i18n="common.next">${escapeHtml(t('common.next'))}</span></button></div><h3><span data-i18n="diagnostics.requestsToCheck">${escapeHtml(t('diagnostics.requestsToCheck'))}</span></h3><p class="muted note"><span data-i18n="diagnostics.qualityNote">${escapeHtml(t('diagnostics.qualityNote'))}</span></p><div id="diagnostic-summaries" class="table-wrap"></div></section>
</main>${localizationScripts(scriptUri, nonce)}<script nonce="${escapeHtml(nonce)}" src="${escapeHtml(scriptUri)}"></script></body></html>`;
}
